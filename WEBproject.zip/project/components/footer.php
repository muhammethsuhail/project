<footer class="footer">

   &copy; copyright @ <?= date('Y'); ?> by <span>MR. AM Suhail</span> || all rights reserved!

</footer>